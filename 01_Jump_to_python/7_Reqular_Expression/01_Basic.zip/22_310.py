import re

print(re.search('short$','Life is too short'))
print(re.search('Life$','Life is too short'))
print(re.search('too$','Life is too short'))
print(re.search('short$','Life is too short, you need python'))
